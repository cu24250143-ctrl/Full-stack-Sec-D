import React, { useState } from "react";

// Discount rule: 10% off when the total reaches the threshold.
// Change these two constants if your marking scheme uses different values.
const DISCOUNT_THRESHOLD = 1000;
const DISCOUNT_RATE = 0.1;

export default function Cart({ products = [] }) {
  // cart: array of { id, qty } kept in insertion order
  const [cart, setCart] = useState([]);

  const add = (id) =>
    setCart((prev) =>
      prev.some((l) => l.id === id)
        ? prev.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l))
        : [...prev, { id, qty: 1 }]
    );

  const inc = (id) =>
    setCart((prev) =>
      prev.map((l) => (l.id === id ? { ...l, qty: l.qty + 1 } : l))
    );

  // Decreasing from 1 removes the line.
  const dec = (id) =>
    setCart((prev) =>
      prev
        .map((l) => (l.id === id ? { ...l, qty: l.qty - 1 } : l))
        .filter((l) => l.qty > 0)
    );

  const remove = (id) => setCart((prev) => prev.filter((l) => l.id !== id));

  const lines = cart
    .map((l) => ({ ...l, product: products.find((p) => p.id === l.id) }))
    .filter((l) => l.product);

  const itemCount = lines.reduce((n, l) => n + l.qty, 0);
  const total = lines.reduce((sum, l) => sum + l.product.price * l.qty, 0);
  const discount = total >= DISCOUNT_THRESHOLD ? total * DISCOUNT_RATE : 0;
  const grandTotal = total - discount;
  const toGo = DISCOUNT_THRESHOLD - total;

  return (
    <div className="shop">
      <header className="shop-header">
        <h1>Mini Store</h1>
        <span className="badge">
          {itemCount} {itemCount === 1 ? "item" : "items"}
        </span>
      </header>

      <div className="shop-grid">
        <section className="panel">
          <h2>Products</h2>
          <ul className="product-list">
            {products.map((p) => (
              <li key={p.id} className="product-card">
                <div className="avatar">{p.name.charAt(0)}</div>
                <div className="product-info">
                  <span className="product-name">{p.name}</span>
                  <span className="product-price">{p.price.toFixed(2)}</span>
                </div>
                <button
                  className="btn btn-primary"
                  data-testid={`add-${p.id}`}
                  onClick={() => add(p.id)}
                >
                  Add
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="panel">
          <h2>Your Cart</h2>
          {lines.length === 0 ? (
            <p className="empty" data-testid="cart-empty">
              Cart is empty
            </p>
          ) : (
            <ul className="cart-list">
              {lines.map(({ id, qty, product }) => (
                <li key={id} className="cart-line">
                  <div className="cart-line-info">
                    <span className="product-name">{product.name}</span>
                    <span className="line-price">
                      {(product.price * qty).toFixed(2)}
                    </span>
                  </div>
                  <div className="cart-line-actions">
                    <div className="stepper">
                      <button
                        className="btn btn-icon"
                        aria-label={`Decrease ${product.name}`}
                        data-testid={`dec-${id}`}
                        onClick={() => dec(id)}
                      >
                        -
                      </button>
                      <span className="qty" data-testid={`qty-${id}`}>
                        {qty}
                      </span>
                      <button
                        className="btn btn-icon"
                        aria-label={`Increase ${product.name}`}
                        data-testid={`inc-${id}`}
                        onClick={() => inc(id)}
                      >
                        +
                      </button>
                    </div>
                    <button
                      className="btn btn-danger"
                      data-testid={`remove-${id}`}
                      onClick={() => remove(id)}
                    >
                      Remove
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}

          <div className="summary">
            {lines.length > 0 && discount === 0 && (
              <p className="hint">
                Spend {toGo.toFixed(2)} more to get{" "}
                {Math.round(DISCOUNT_RATE * 100)}% off
              </p>
            )}
            <p className="row" data-testid="total">
              Total: {total.toFixed(2)}
            </p>
            {discount > 0 && (
              <>
                <p className="row row-discount" data-testid="discount">
                  Discount: {discount.toFixed(2)}
                </p>
                <p className="row row-grand" data-testid="grand-total">
                  Grand Total: {grandTotal.toFixed(2)}
                </p>
              </>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
