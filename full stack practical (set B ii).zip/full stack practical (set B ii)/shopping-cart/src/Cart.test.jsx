import React from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import Cart from "./Cart.jsx";

const products = [
  { id: 1, name: "Keyboard", price: 500 },
  { id: 2, name: "Mouse", price: 250 },
  { id: 3, name: "Cable", price: 20 },
];

const t = (id) => screen.getByTestId(id);

test("shows empty message initially", () => {
  render(<Cart products={products} />);
  expect(t("cart-empty")).toHaveTextContent("Cart is empty");
});

test("adds a product and shows total", async () => {
  render(<Cart products={products} />);
  await userEvent.click(t("add-2"));
  expect(t("qty-2")).toHaveTextContent("1");
  expect(t("total")).toHaveTextContent("Total: 250.00");
  expect(screen.queryByTestId("cart-empty")).toBeNull();
});

test("adding the same product twice increases quantity", async () => {
  render(<Cart products={products} />);
  await userEvent.click(t("add-1"));
  await userEvent.click(t("add-1"));
  expect(t("qty-1")).toHaveTextContent("2");
});

test("inc, dec and remove work", async () => {
  render(<Cart products={products} />);
  await userEvent.click(t("add-3"));
  await userEvent.click(t("inc-3"));
  expect(t("qty-3")).toHaveTextContent("2");
  expect(t("total")).toHaveTextContent("Total: 40.00");
  await userEvent.click(t("dec-3"));
  expect(t("qty-3")).toHaveTextContent("1");
  await userEvent.click(t("remove-3"));
  expect(t("cart-empty")).toBeInTheDocument();
});

test("no discount below threshold", async () => {
  render(<Cart products={products} />);
  await userEvent.click(t("add-1"));
  expect(screen.queryByTestId("discount")).toBeNull();
  expect(screen.queryByTestId("grand-total")).toBeNull();
});

test("applies discount at 1000", async () => {
  render(<Cart products={products} />);
  await userEvent.click(t("add-1"));
  await userEvent.click(t("add-1"));
  expect(t("total")).toHaveTextContent("Total: 1000.00");
  expect(t("discount")).toHaveTextContent("Discount: 100.00");
  expect(t("grand-total")).toHaveTextContent("Grand Total: 900.00");
});
