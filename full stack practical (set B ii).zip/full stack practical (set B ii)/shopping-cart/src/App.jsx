import React from "react";
import Cart from "./Cart.jsx";

const products = [
  { id: 1, name: "Keyboard", price: 500 },
  { id: 2, name: "Mouse", price: 250 },
  { id: 3, name: "Headphones", price: 750 },
  { id: 4, name: "Cable", price: 20 },
];

export default function App() {
  return <Cart products={products} />;
}
