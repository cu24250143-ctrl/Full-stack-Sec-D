const jwt = require('jsonwebtoken');
const { app, JWT_SECRET } = require('./server');

let failures = 0;
function check(name, actualStatus, actualBody, expectedStatus, expectedBody) {
  const pass =
    actualStatus === expectedStatus &&
    JSON.stringify(actualBody) === JSON.stringify(expectedBody);
  if (!pass) failures++;
  console.log(`${pass ? 'PASS' : 'FAIL'}  ${name}`, pass ? '' : `-> ${actualStatus} ${JSON.stringify(actualBody)}`);
}

const server = app.listen(0, async () => {
  const base = `http://localhost:${server.address().port}`;
  const call = async (method, path, body, headers = {}) => {
    const r = await fetch(base + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...headers },
      body: body === undefined ? undefined : typeof body === 'string' ? body : JSON.stringify(body),
    });
    return { status: r.status, body: await r.json() };
  };

  let r;
  r = await call('POST', '/register', { username: 'alice', password: 'secret1' });
  check('register ok', r.status, r.body, 201, { message: 'User registered' });

  r = await call('POST', '/register', { username: 'alice', password: 'secret1' });
  check('register duplicate', r.status, r.body, 409, { error: 'Username already exists' });

  r = await call('POST', '/register', { username: '', password: 'secret1' });
  check('register empty username', r.status, r.body, 400, { error: 'Invalid input' });

  r = await call('POST', '/register', { password: 'secret1' });
  check('register missing username', r.status, r.body, 400, { error: 'Invalid input' });

  r = await call('POST', '/register', { username: 'bob', password: '12345' });
  check('register short password', r.status, r.body, 400, { error: 'Invalid input' });

  r = await call('POST', '/register', '{bad json');
  check('register malformed JSON', r.status, r.body, 400, { error: 'Invalid input' });

  r = await call('POST', '/login', { username: 'alice', password: 'wrong' });
  check('login wrong password', r.status, r.body, 401, { error: 'Invalid credentials' });

  r = await call('POST', '/login', { username: 'nobody', password: 'secret1' });
  check('login unknown user', r.status, r.body, 401, { error: 'Invalid credentials' });

  r = await call('POST', '/login', { username: 'alice', password: 'secret1' });
  const token = r.body.token;
  const decoded = token && jwt.decode(token);
  const loginOk =
    r.status === 200 && decoded && decoded.username === 'alice' && decoded.exp - decoded.iat === 3600;
  if (!loginOk) failures++;
  console.log(`${loginOk ? 'PASS' : 'FAIL'}  login ok (token has username, expires in 1h)`);

  r = await call('GET', '/profile', undefined, { Authorization: `Bearer ${token}` });
  check('profile valid token', r.status, r.body, 200, { username: 'alice' });

  const unauth = { error: 'Unauthorized' };
  r = await call('GET', '/profile');
  check('profile no header', r.status, r.body, 401, unauth);

  r = await call('GET', '/profile', undefined, { Authorization: 'Bearer not.a.token' });
  check('profile malformed token', r.status, r.body, 401, unauth);

  const forged = jwt.sign({ username: 'alice' }, 'wrong-secret', { expiresIn: '1h' });
  r = await call('GET', '/profile', undefined, { Authorization: `Bearer ${forged}` });
  check('profile bad signature', r.status, r.body, 401, unauth);

  const expired = jwt.sign({ username: 'alice' }, JWT_SECRET, { expiresIn: -10 });
  r = await call('GET', '/profile', undefined, { Authorization: `Bearer ${expired}` });
  check('profile expired token', r.status, r.body, 401, unauth);

  console.log(failures === 0 ? '\nAll tests passed' : `\n${failures} test(s) failed`);
  server.close();
  process.exit(failures === 0 ? 0 : 1);
});