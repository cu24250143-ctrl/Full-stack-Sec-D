const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const JWT_SECRET = process.env.JWT_SECRET || 'change-this-secret-in-production';
const PORT = process.env.PORT || 3000;

// In-memory user store: username -> { username, passwordHash }
const users = new Map();

// ---------- POST /register ----------
app.post('/register', async (req, res) => {
  const { username, password } = req.body || {};

  if (
    typeof username !== 'string' ||
    username.trim() === '' ||
    typeof password !== 'string' ||
    password.length < 6
  ) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  if (users.has(username)) {
    return res.status(409).json({ error: 'Username already exists' });
  }

  const passwordHash = await bcrypt.hash(password, 10);
  // Re-check after the await so two concurrent requests can't both register
  if (users.has(username)) {
    return res.status(409).json({ error: 'Username already exists' });
  }
  users.set(username, { username, passwordHash });

  return res.status(201).json({ message: 'User registered' });
});

// ---------- POST /login ----------
app.post('/login', async (req, res) => {
  const { username, password } = req.body || {};

  const user = typeof username === 'string' ? users.get(username) : undefined;
  const ok =
    user &&
    typeof password === 'string' &&
    (await bcrypt.compare(password, user.passwordHash));

  if (!ok) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign({ username: user.username }, JWT_SECRET, {
    algorithm: 'HS256',
    expiresIn: '1h',
  });

  return res.status(200).json({ token });
});

// ---------- Auth middleware ----------
function authenticate(req, res, next) {
  const header = req.headers.authorization;
  if (!header) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const parts = header.split(' ');
  if (parts.length !== 2 || parts[0].toLowerCase() !== 'bearer' || !parts[1]) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    // Throws on malformed token, bad signature or expiry
    req.user = jwt.verify(parts[1], JWT_SECRET, { algorithms: ['HS256'] });
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
}

// ---------- GET /profile ----------
app.get('/profile', authenticate, (req, res) => {
  return res.status(200).json({ username: req.user.username });
});

// Malformed JSON body -> treat as invalid input
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Invalid input' });
  }
  next(err);
});

if (require.main === module) {
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}

module.exports = { app, JWT_SECRET };